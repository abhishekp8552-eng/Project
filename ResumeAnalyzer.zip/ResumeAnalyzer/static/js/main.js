// Main Client-Side Logic for Resume Analyzer
let currentAnalysisResult = null;
let selectedFile = null;

document.addEventListener("DOMContentLoaded", () => {
    initFileHandlers();
    initSubtabs();
    initNavigationTabs();
});

// ---------------------------------------------------------
// Subtab switching (Upload File vs Paste Text)
// ---------------------------------------------------------
function initSubtabs() {
    const subtabBtns = document.querySelectorAll(".subtab-btn");
    subtabBtns.forEach(btn => {
        btn.addEventListener("click", () => {
            const parent = btn.closest(".input-card");
            parent.querySelectorAll(".subtab-btn").forEach(b => b.classList.remove("active"));
            btn.classList.add("active");

            const targetTab = btn.getAttribute("data-tab");
            if (targetTab === "upload") {
                document.getElementById("drop-zone-container").style.display = "block";
                document.getElementById("paste-zone-container").style.display = "none";
            } else if (targetTab === "paste") {
                document.getElementById("drop-zone-container").style.display = "none";
                document.getElementById("paste-zone-container").style.display = "block";
            }
        });
    });
}

// ---------------------------------------------------------
// Navigation Tabs in Results Dashboard
// ---------------------------------------------------------
function initNavigationTabs() {
    const tabBtns = document.querySelectorAll(".tab-btn");
    tabBtns.forEach(btn => {
        btn.addEventListener("click", () => {
            tabBtns.forEach(b => b.classList.remove("active"));
            document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));

            btn.classList.add("active");
            const targetId = btn.getAttribute("data-panel");
            const panel = document.getElementById(targetId);
            if (panel) panel.classList.add("active");
        });
    });
}

// ---------------------------------------------------------
// File Drop Zone Handling
// ---------------------------------------------------------
function initFileHandlers() {
    const dropZone = document.getElementById("drop-zone");
    const fileInput = document.getElementById("file-input");
    const fileStatus = document.getElementById("file-status");
    const fileNameDisplay = document.getElementById("selected-file-name");
    const removeFileBtn = document.getElementById("btn-remove-file");

    if (!dropZone) return;

    dropZone.addEventListener("click", () => fileInput.click());

    ["dragenter", "dragover"].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            dropZone.classList.add("dragover");
        });
    });

    ["dragleave", "drop"].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            dropZone.classList.remove("dragover");
        });
    });

    dropZone.addEventListener("drop", (e) => {
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            handleFileSelect(e.dataTransfer.files[0]);
        }
    });

    fileInput.addEventListener("change", (e) => {
        if (e.target.files && e.target.files.length > 0) {
            handleFileSelect(e.target.files[0]);
        }
    });

    if (removeFileBtn) {
        removeFileBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            selectedFile = null;
            fileInput.value = "";
            fileStatus.classList.remove("show");
            dropZone.style.display = "block";
        });
    }

    function handleFileSelect(file) {
        selectedFile = file;
        fileNameDisplay.textContent = `${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
        fileStatus.classList.add("show");
        dropZone.style.display = "none";
    }
}

// ---------------------------------------------------------
// Load Pre-built Samples
// ---------------------------------------------------------
async function loadSample(role) {
    try {
        const response = await fetch(`/api/sample/${role}`);
        const data = await response.json();
        if (data.resume_text) {
            // Switch to paste tab and populate
            const pasteTabBtn = document.querySelector('[data-tab="paste"]');
            if (pasteTabBtn) pasteTabBtn.click();

            document.getElementById("resume-text-input").value = data.resume_text;
            document.getElementById("jd-text-input").value = data.jd_text || "";

            // Trigger analysis automatically
            runAnalysis();
        }
    } catch (err) {
        alert("Failed to load sample: " + err.message);
    }
}

// ---------------------------------------------------------
// Run Analysis Form Submission
// ---------------------------------------------------------
async function runAnalysis() {
    const spinner = document.getElementById("spinner-container");
    const resultsContainer = document.getElementById("results-container");
    const resumeTextInput = document.getElementById("resume-text-input");
    const jdTextInput = document.getElementById("jd-text-input");

    const formData = new FormData();

    // Check if file is selected or text is entered
    if (selectedFile) {
        formData.append("resume_file", selectedFile);
    } else if (resumeTextInput.value.trim()) {
        formData.append("resume_text", resumeTextInput.value.trim());
    } else {
        alert("Please upload a resume file (PDF/DOCX/TXT) or paste your resume text.");
        return;
    }

    if (jdTextInput.value.trim()) {
        formData.append("jd_text", jdTextInput.value.trim());
    }

    // Show spinner
    spinner.style.display = "block";
    resultsContainer.classList.remove("show");

    try {
        const res = await fetch("/api/analyze", {
            method: "POST",
            body: formData
        });

        const data = await res.json();
        spinner.style.display = "none";

        if (data.error) {
            alert("Error: " + data.error);
            return;
        }

        currentAnalysisResult = data;
        renderResults(data);
        resultsContainer.classList.add("show");
        resultsContainer.scrollIntoView({ behavior: "smooth" });

    } catch (error) {
        spinner.style.display = "none";
        alert("An error occurred during analysis: " + error.message);
    }
}

// ---------------------------------------------------------
// Render Results into Dashboard
// ---------------------------------------------------------
function renderResults(data) {
    const ats = data.ats_score || {};
    const jd = data.jd_match || null;
    const profile = data.profile || {};
    const skills = data.skills || {};
    const feedback = data.feedback || {};

    // 1. Metric Cards
    document.getElementById("metric-ats-score").textContent = ats.total_score || "0";
    const badgeEl = document.getElementById("metric-ats-badge");
    badgeEl.textContent = `${ats.rating || 'N/A'} (Grade ${ats.grade || 'C'})`;
    badgeEl.className = "score-badge " + getScoreBadgeClass(ats.badge_color);

    // JD Match Metric
    const jdCard = document.getElementById("metric-jd-card");
    if (jd && !jd.error) {
        jdCard.style.display = "block";
        document.getElementById("metric-jd-score").textContent = `${jd.overall_match_score}%`;
        document.getElementById("metric-jd-sub").textContent = `Skills Match: ${jd.skill_match_percentage}% • TF-IDF: ${jd.tfidf_similarity}%`;
    } else {
        jdCard.style.display = "none";
    }

    // Skills & Experience Metrics
    document.getElementById("metric-skills-count").textContent = skills.total_count || "0";
    document.getElementById("metric-skills-sub").textContent = `${Object.keys(skills.categorized || {}).length} Categories Identified`;

    const years = profile.experience?.estimated_years || 0;
    document.getElementById("metric-exp-years").textContent = `~${years} Yrs`;
    document.getElementById("metric-exp-sub").textContent = profile.experience?.detected_titles?.slice(0, 2).join(", ") || "General Experience";

    // 2. Pillars Breakdown
    renderPillars(ats.breakdown || {});

    // 3. Skills Matrix
    renderSkillsMatrix(skills, jd);

    // 4. Recommendations
    renderFeedback(feedback);

    // 5. Candidate Profile
    renderProfile(profile, data.metadata);

    // 6. Resume Preview & Content Metrics
    renderPreview(data);
}

function getScoreBadgeClass(color) {
    if (color === "success") return "badge-excellent";
    if (color === "primary") return "badge-good";
    if (color === "warning") return "badge-warning";
    return "badge-danger";
}

function renderPillars(breakdown) {
    const container = document.getElementById("pillars-container");
    container.innerHTML = "";

    for (const [key, item] of Object.entries(breakdown)) {
        const pillarHtml = `
            <div class="pillar-card">
                <div class="pillar-header">
                    <span>${item.label}</span>
                    <span>${item.score} / ${item.max} pts (${item.percentage}%)</span>
                </div>
                <div class="progress-track">
                    <div class="progress-bar" style="width: ${item.percentage}%;"></div>
                </div>
            </div>
        `;
        container.insertAdjacentHTML("beforeend", pillarHtml);
    }
}

function renderSkillsMatrix(skills, jd) {
    const container = document.getElementById("skills-container");
    container.innerHTML = "";

    // If JD is present, highlight matched vs missing first
    if (jd && !jd.error) {
        let jdComparisonHtml = `
            <div class="skill-category-group" style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 1.25rem; border-radius: 12px; margin-bottom: 2rem;">
                <h4 style="margin-bottom: 0.75rem; color: #065f46; font-size: 1rem;">🎯 Matched Skills from Job Description (${jd.matched_skills_count})</h4>
                <div class="skills-chip-container" style="margin-bottom: 1.25rem;">
                    ${jd.matched_skills.map(s => `<span class="skill-chip matched">✓ ${s}</span>`).join("") || '<span style="color:#64748b; font-size:0.85rem;">None</span>'}
                </div>

                <h4 style="margin-bottom: 0.75rem; color: #991b1b; font-size: 1rem;">⚠️ Missing Skills Required in Job Description (${jd.missing_skills_count})</h4>
                <div class="skills-chip-container">
                    ${jd.missing_skills.map(s => `<span class="skill-chip missing">+ ${s}</span>`).join("") || '<span style="color:#64748b; font-size:0.85rem;">None (Full Coverage!)</span>'}
                </div>
            </div>
        `;
        container.insertAdjacentHTML("beforeend", jdComparisonHtml);
    }

    // Categorized breakdown
    const categories = skills.categorized || {};
    if (Object.keys(categories).length === 0) {
        container.innerHTML += "<p style='color:#64748b;'>No specific skills identified.</p>";
        return;
    }

    for (const [catName, skillList] of Object.entries(categories)) {
        const groupHtml = `
            <div class="skill-category-group">
                <div class="skill-category-title">
                    <span>${catName}</span>
                    <span style="font-size:0.75rem; font-weight:600; color:#64748b; background:#e2e8f0; padding:0.15rem 0.5rem; border-radius:999px;">${skillList.length}</span>
                </div>
                <div class="skills-chip-container">
                    ${skillList.map(skill => `<span class="skill-chip">${skill}</span>`).join("")}
                </div>
            </div>
        `;
        container.insertAdjacentHTML("beforeend", groupHtml);
    }
}

function renderFeedback(feedback) {
    const container = document.getElementById("feedback-container");
    container.innerHTML = "";

    const critical = feedback.critical_fixes || [];
    const improvements = feedback.improvements || [];
    const strengths = feedback.strengths || [];

    if (critical.length > 0) {
        critical.forEach(item => {
            const html = `
                <div class="feedback-box feedback-critical">
                    <div class="feedback-tag">High Priority Fix</div>
                    <div class="feedback-title">${item.category}: ${item.issue}</div>
                    <div class="feedback-desc"><strong>Action:</strong> ${item.recommendation}</div>
                </div>
            `;
            container.insertAdjacentHTML("beforeend", html);
        });
    }

    if (improvements.length > 0) {
        improvements.forEach(item => {
            const html = `
                <div class="feedback-box feedback-improvement">
                    <div class="feedback-tag">Recommended Optimization</div>
                    <div class="feedback-title">${item.category}: ${item.issue}</div>
                    <div class="feedback-desc"><strong>Action:</strong> ${item.recommendation}</div>
                </div>
            `;
            container.insertAdjacentHTML("beforeend", html);
        });
    }

    if (strengths.length > 0) {
        strengths.forEach(s => {
            const html = `
                <div class="feedback-box feedback-strength">
                    <div class="feedback-tag">Strength</div>
                    <div class="feedback-title">${s}</div>
                </div>
            `;
            container.insertAdjacentHTML("beforeend", html);
        });
    }
}

function renderProfile(profile, metadata) {
    const container = document.getElementById("profile-container");
    const contact = profile.contact || {};
    const edu = profile.education || {};
    const exp = profile.experience || {};

    container.innerHTML = `
        <div class="profile-card">
            <h3 style="margin-bottom: 1rem; font-size: 1.1rem; color: #0f172a;">👤 Extracted Candidate Details</h3>
            <table class="profile-table">
                <tr><td>Name</td><td><strong>${profile.name || 'Not detected'}</strong></td></tr>
                <tr><td>Email</td><td>${contact.email || '<span style="color:#ef4444;">Missing</span>'}</td></tr>
                <tr><td>Phone</td><td>${contact.phone || '<span style="color:#ef4444;">Missing</span>'}</td></tr>
                <tr><td>LinkedIn</td><td>${contact.linkedin ? `<a href="https://${contact.linkedin}" target="_blank" style="color:#4f46e5;">${contact.linkedin}</a>` : '<span style="color:#f59e0b;">Not found</span>'}</td></tr>
                <tr><td>GitHub</td><td>${contact.github ? `<a href="https://${contact.github}" target="_blank" style="color:#4f46e5;">${contact.github}</a>` : '<span style="color:#64748b;">Not found</span>'}</td></tr>
                <tr><td>Degrees</td><td>${edu.degrees?.join(', ') || 'No degree detected'}</td></tr>
                <tr><td>Experience Estimated</td><td>${exp.estimated_years} years</td></tr>
                <tr><td>Detected Job Titles</td><td>${exp.detected_titles?.join(', ') || 'None'}</td></tr>
                <tr><td>File Metadata</td><td>${metadata?.file_type || 'Text'} • ${metadata?.word_count || 0} words</td></tr>
            </table>
        </div>
    `;
}

function renderPreview(data) {
    const previewContainer = document.getElementById("preview-container");
    const metrics = data.impact_metrics || {};
    const verbs = data.action_verbs || {};

    let html = `
        <div style="background: white; border: 1px solid #e2e8f0; border-radius: 12px; padding: 1.5rem; margin-bottom: 1.5rem;">
            <h3 style="margin-bottom: 0.75rem; font-size: 1.05rem;">📊 Content Metrics & Power Words</h3>
            <p style="font-size: 0.85rem; color: #475569; margin-bottom: 1rem;">
                Found <strong>${metrics.quantified_count || 0}</strong> quantified achievement statements and 
                <strong>${verbs.total_strong_verbs || 0}</strong> leadership action verbs.
            </p>
            ${metrics.examples && metrics.examples.length > 0 ? `
                <div style="background: #f8fafc; border-left: 3px solid #10b981; padding: 1rem; border-radius: 8px; margin-bottom: 1.25rem;">
                    <div style="font-size: 0.85rem; font-weight: 700; color: #065f46; margin-bottom: 0.5rem;">Sample Quantified Achievements Found:</div>
                    <ul style="padding-left: 1.25rem; font-size: 0.85rem; color: #334155;">
                        ${metrics.examples.map(ex => `<li style="margin-bottom: 0.35rem;">${ex}</li>`).join("")}
                    </ul>
                </div>
            ` : ''}

            <h4 style="margin-bottom: 0.5rem; font-size: 0.95rem; color: #0f172a;">📄 Extracted Text Preview</h4>
            <pre style="background: #0f172a; color: #e2e8f0; padding: 1rem; border-radius: 8px; font-size: 0.8rem; overflow-x: auto; white-space: pre-wrap; max-height: 350px;">${data.resume_text_preview || 'No preview available'}</pre>
        </div>
    `;
    previewContainer.innerHTML = html;
}

// ---------------------------------------------------------
// Export Analysis as Printable Report
// ---------------------------------------------------------
function printReport() {
    window.print();
}

function exportJSON() {
    if (!currentAnalysisResult) {
        alert("Run an analysis first!");
        return;
    }
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(currentAnalysisResult, null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `Resume_Analysis_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
}
