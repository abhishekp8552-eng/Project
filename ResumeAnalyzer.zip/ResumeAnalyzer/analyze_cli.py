"""
Resume Analyzer - Command Line Interface (CLI).
Enables terminal-based resume parsing, ATS scoring, and JD matching.
Zero LLM API keys needed.
"""

import sys
import os
import argparse
import json

# Ensure UTF-8 output on Windows consoles
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from core.analyzer import ResumeAnalyzerEngine


def print_banner():
    print("=" * 70)
    print("         RESUME ANALYZER (OFFLINE NLP / ATS ENGINE)           ")
    print("        No LLM API Keys Needed - 100% Private & Local         ")
    print("=" * 70)


def print_report(result: dict):
    if not result.get("success"):
        print(f"\n[ERROR] {result.get('error')}")
        return

    profile = result.get("profile", {})
    contact = profile.get("contact", {})
    exp = profile.get("experience", {})
    edu = profile.get("education", {})
    skills = result.get("skills", {})
    ats = result.get("ats_score", {})
    jd = result.get("jd_match", {})
    feedback = result.get("feedback", {})

    print(f"\n[+] CANDIDATE PROFILE:")
    print(f"   Name:       {profile.get('name')}")
    print(f"   Email:      {contact.get('email') or 'Not found'}")
    print(f"   Phone:      {contact.get('phone') or 'Not found'}")
    print(f"   LinkedIn:   {contact.get('linkedin') or 'Not found'}")
    print(f"   GitHub:     {contact.get('github') or 'Not found'}")
    print(f"   Experience: ~{exp.get('estimated_years', 0)} years detected")
    print(f"   Degrees:    {', '.join(edu.get('degrees', [])) or 'None detected'}")

    print("\n" + "-" * 70)
    print(f"[*] ATS READINESS SCORE: {ats.get('total_score', 0)} / 100  [{ats.get('rating')}] (Grade: {ats.get('grade')})")
    print("-" * 70)
    for key, item in ats.get("breakdown", {}).items():
        bar_len = int(item["score"] / item["max"] * 20)
        bar = "#" * bar_len + "-" * (20 - bar_len)
        print(f"   {item['label'][:32]:<32} : {item['score']:>4.1f}/{item['max']:<2}  [{bar}] {item['percentage']}%")

    print(f"\n[*] TECHNICAL SKILLS DETECTED ({skills.get('total_count', 0)} total):")
    for cat, sk_list in skills.get("categorized", {}).items():
        print(f"   * {cat}: {', '.join(sk_list)}")

    if jd:
        print("\n" + "-" * 70)
        print(f"[*] JOB DESCRIPTION ALIGNMENT: {jd.get('overall_match_score', 0)}% MATCH")
        print("-" * 70)
        print(f"   * TF-IDF Semantic Similarity: {jd.get('tfidf_similarity', 0)}%")
        print(f"   * Skills Match Rate:          {jd.get('skill_match_percentage', 0)}% ({jd.get('matched_skills_count')}/{jd.get('jd_skills_count')})")
        print(f"   * Matched Skills:             {', '.join(jd.get('matched_skills', [])) or 'None'}")
        if jd.get("missing_skills"):
            print(f"   * [!] Missing Skills in Resume: {', '.join(jd.get('missing_skills', []))}")
        if jd.get("missing_top_keywords"):
            print(f"   * [?] Missing High-Value Terms: {', '.join(jd.get('missing_top_keywords', []))}")

    print("\n" + "-" * 70)
    print("[*] ACTIONABLE RECOMMENDATIONS & FIXES:")
    print("-" * 70)
    critical = feedback.get("critical_fixes", [])
    if critical:
        print("   [!] Critical Fixes (High Priority):")
        for c in critical:
            print(f"      - [{c['category']}] {c['issue']}")
            print(f"        -> Action: {c['recommendation']}")

    improvements = feedback.get("improvements", [])
    if improvements:
        print("\n   [+] Recommended Polish:")
        for imp in improvements:
            print(f"      - [{imp['category']}] {imp['issue']}")
            print(f"        -> Action: {imp['recommendation']}")

    strengths = feedback.get("strengths", [])
    if strengths:
        print("\n   [v] Strong Points:")
        for s in strengths:
            print(f"      + {s}")

    print("\n" + "=" * 70)


def main():
    parser = argparse.ArgumentParser(description="Offline Resume Analyzer without LLM APIs")
    parser.add_argument("--resume", "-r", type=str, help="Path to resume file (PDF, DOCX, TXT)")
    parser.add_argument("--jd", "-j", type=str, help="Path to job description file (TXT)")
    parser.add_argument("--json", action="store_true", help="Output raw JSON instead of text report")
    parser.add_argument("--sample", action="store_true", help="Run analysis on bundled sample resume & JD")

    args = parser.parse_args()

    engine = ResumeAnalyzerEngine()

    if args.sample:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        resume_sample = os.path.join(script_dir, "samples", "sample_resume_swe.txt")
        jd_sample = os.path.join(script_dir, "samples", "sample_jd_swe.txt")

        jd_text = None
        if os.path.exists(jd_sample):
            with open(jd_sample, "r", encoding="utf-8") as f:
                jd_text = f.read()

        print_banner()
        print(f"Running sample analysis on: {resume_sample}")
        result = engine.analyze(resume_path=resume_sample, jd_text=jd_text)
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print_report(result)
        return

    if not args.resume:
        print_banner()
        print("Usage:")
        print("  python analyze_cli.py --resume path/to/resume.pdf")
        print("  python analyze_cli.py --resume path/to/resume.pdf --jd path/to/job.txt")
        print("  python analyze_cli.py --sample")
        sys.exit(1)

    jd_text = None
    if args.jd:
        if os.path.exists(args.jd):
            with open(args.jd, "r", encoding="utf-8") as f:
                jd_text = f.read()
        else:
            jd_text = args.jd

    print_banner()
    result = engine.analyze(resume_path=args.resume, jd_text=jd_text)

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print_report(result)


if __name__ == "__main__":
    main()
