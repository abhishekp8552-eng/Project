"""
Resume Parser Module.
Extracts contact information, candidate name, education, experience,
quantifiable metrics, and standard sections without external APIs or LLMs.
"""

import re
from datetime import datetime
from typing import Dict, List, Any, Optional
from core.skills_database import (
    COMMON_DEGREES,
    STANDARD_SECTIONS,
    ACTION_VERBS,
    ALL_ACTION_VERBS,
    WEAK_WORDS
)
from core.cleaner import extract_sentences


class ResumeParser:
    """Parses structural entities from cleaned resume text."""

    # Common email regex
    EMAIL_REGEX = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b")

    # Flexible phone number regex (matches US, International, India, etc.)
    PHONE_REGEX = re.compile(
        r"(?:(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}|\+?\d{1,4}[-.\s]?\d{9,10})\b"
    )

    # Social and web links
    LINKEDIN_REGEX = re.compile(r"(?:https?://)?(?:www\.)?linkedin\.com/in/([A-Za-z0-9_-]+)", re.IGNORECASE)
    GITHUB_REGEX = re.compile(r"(?:https?://)?(?:www\.)?github\.com/([A-Za-z0-9_-]+)", re.IGNORECASE)
    URL_REGEX = re.compile(r"https?://(?:www\.)?[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?:/[A-Za-z0-9_.-]*)*", re.IGNORECASE)

    # Date ranges for experience calculation
    DATE_RANGE_REGEX = re.compile(
        r"(?P<start>(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+)?(?P<start_year>19\d\d|20\d\d)"
        r"\s*(?:-|–|—|to)\s*"
        r"(?P<end>(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+)?(?P<end_year>19\d\d|20\d\d|present|current|now)",
        re.IGNORECASE
    )

    # Direct experience mention, e.g. "5+ years of experience"
    EXP_MENTION_REGEX = re.compile(
        r"(\d+(?:\.\d+)?)\s*\+?\s*(?:years|yrs)(?:\s+of)?\s+(?:experience|exp)",
        re.IGNORECASE
    )

    # Common tech job titles
    COMMON_TITLES = [
        "software engineer", "senior software engineer", "staff software engineer",
        "lead software engineer", "software developer", "full stack developer",
        "frontend developer", "backend developer", "web developer", "mobile developer",
        "ios developer", "android developer", "data scientist", "senior data scientist",
        "machine learning engineer", "ai engineer", "data engineer", "data analyst",
        "devops engineer", "cloud architect", "site reliability engineer", "sre",
        "systems engineer", "database administrator", "qa engineer", "test automation engineer",
        "product manager", "project manager", "scrum master", "technical lead",
        "engineering manager", "solutions architect", "security analyst", "cybersecurity engineer"
    ]

    def __init__(self, text: str):
        self.raw_text = text
        self.lines = [line.strip() for line in text.split("\n") if line.strip()]

    def extract_contact_info(self) -> Dict[str, Any]:
        """Extract email, phone, links, and portfolio handles."""
        emails = self.EMAIL_REGEX.findall(self.raw_text)
        phones = self.PHONE_REGEX.findall(self.raw_text)
        
        # Clean phone numbers (filter out dates / numbers mistaken as phones)
        cleaned_phones = []
        for p in phones:
            digits = re.sub(r"\D", "", p)
            if 7 <= len(digits) <= 15:
                cleaned_phones.append(p.strip())

        linkedin_match = self.LINKEDIN_REGEX.search(self.raw_text)
        github_match = self.GITHUB_REGEX.search(self.raw_text)
        
        # Find all URLs and filter out linkedin and github to get portfolio/website
        all_urls = self.URL_REGEX.findall(self.raw_text)
        websites = [
            u for u in all_urls
            if "linkedin.com" not in u.lower() and "github.com" not in u.lower()
        ]

        return {
            "email": emails[0] if emails else None,
            "all_emails": list(set(emails)),
            "phone": cleaned_phones[0] if cleaned_phones else None,
            "all_phones": list(set(cleaned_phones)),
            "linkedin": linkedin_match.group(0) if linkedin_match else None,
            "linkedin_handle": linkedin_match.group(1) if linkedin_match else None,
            "github": github_match.group(0) if github_match else None,
            "github_handle": github_match.group(1) if github_match else None,
            "portfolio": websites[0] if websites else None
        }

    def extract_name(self) -> str:
        """Heuristic name extraction from top resume lines."""
        ignore_words = {
            "resume", "curriculum", "vitae", "cv", "profile", "contact",
            "phone", "email", "summary", "experience", "education", "skills",
            "page", "address", "street", "city", "github", "linkedin"
        }

        # Look closely at the first 5 non-empty lines
        for line in self.lines[:5]:
            # Strip extra symbols
            cleaned = re.sub(r"[^a-zA-Z\s.-]", "", line).strip()
            words = cleaned.split()
            if 2 <= len(words) <= 4:
                # Check that none of the words are ignore keywords or contact headers
                lower_words = [w.lower() for w in words]
                if not any(w in ignore_words for w in lower_words):
                    # Check capitalization
                    if all(w[0].isupper() for w in words if w):
                        return cleaned
        
        # Fallback to first line if reasonably short
        if self.lines and len(self.lines[0].split()) <= 4:
            first = self.lines[0].strip()
            if not any(ig in first.lower() for ig in ignore_words):
                return first

        return "Candidate"

    def extract_sections(self) -> Dict[str, Dict[str, Any]]:
        """Identify which standard resume sections exist and their text."""
        sections = {}
        section_headers = {
            "Summary": ["summary", "professional summary", "about me", "career objective", "objective"],
            "Experience": ["experience", "work experience", "employment history", "professional experience", "work history"],
            "Education": ["education", "academic background", "qualifications", "academics"],
            "Skills": ["skills", "technical skills", "core competencies", "skills & tools", "technologies"],
            "Projects": ["projects", "personal projects", "key projects", "notable projects", "academic projects"],
            "Certifications": ["certifications", "licenses", "certificates", "courses"],
            "Awards": ["awards", "honors", "achievements", "accomplishments"]
        }

        # Find line indices where sections start
        found_indices = []
        for idx, line in enumerate(self.lines):
            line_clean = line.strip().lower().rstrip(":")
            for sec_name, keywords in section_headers.items():
                if line_clean in keywords or any(line_clean == f"{kw}" for kw in keywords):
                    found_indices.append((idx, sec_name))
                    break

        # Sort indices
        found_indices.sort(key=lambda x: x[0])

        # Slice text for each section
        for i, (start_idx, sec_name) in enumerate(found_indices):
            end_idx = found_indices[i + 1][0] if i + 1 < len(found_indices) else len(self.lines)
            sec_content = "\n".join(self.lines[start_idx + 1:end_idx])
            sections[sec_name] = {
                "present": True,
                "content": sec_content,
                "word_count": len(sec_content.split())
            }

        # Check missing sections
        for sec_name in section_headers.keys():
            if sec_name not in sections:
                # Quick keyword search check as fallback
                pattern = re.compile(rf"\b{re.escape(sec_name.lower())}\b", re.IGNORECASE)
                is_mentioned = bool(pattern.search(self.raw_text))
                sections[sec_name] = {
                    "present": is_mentioned,
                    "content": "",
                    "word_count": 0
                }

        return sections

    def extract_education(self) -> Dict[str, Any]:
        """Detect degrees, graduation years, GPA, and institutions."""
        detected_degrees = []
        for deg in COMMON_DEGREES:
            pattern = rf"\b{re.escape(deg)}\b"
            if re.search(pattern, self.raw_text, re.IGNORECASE):
                detected_degrees.append(deg.upper())

        # Graduation year patterns (e.g. 2018, 2022)
        years = re.findall(r"\b(20\d\d|19\d\d)\b", self.raw_text)
        sorted_years = sorted(list(set(years)))

        # GPA / Percentage search
        gpa_match = re.search(r"(?:gpa|cgpa)[:\s]+([0-9]\.[0-9]+(?:/[0-9]\.?[0-9]*)?)", self.raw_text, re.IGNORECASE)
        gpa = gpa_match.group(1) if gpa_match else None

        return {
            "degrees": list(set(detected_degrees)),
            "years_mentioned": sorted_years,
            "gpa": gpa,
            "has_education": len(detected_degrees) > 0 or bool(self.extract_sections().get("Education", {}).get("present"))
        }

    def estimate_experience(self) -> Dict[str, Any]:
        """Calculate estimated years of experience and detected job titles."""
        current_year = datetime.now().year
        total_months = 0
        spans = []

        # Check direct mentions (e.g. "5+ years of experience")
        direct_mentions = self.EXP_MENTION_REGEX.findall(self.raw_text)
        direct_exp = max([float(x) for x in direct_mentions]) if direct_mentions else 0.0

        # Parse date spans
        for match in self.DATE_RANGE_REGEX.finditer(self.raw_text):
            try:
                start_y = int(match.group("start_year"))
                end_str = match.group("end_year").lower()
                end_y = current_year if ("present" in end_str or "current" in end_str or "now" in end_str) else int(end_str)
                if 1990 <= start_y <= current_year and start_y <= end_y <= current_year + 5:
                    years_diff = end_y - start_y
                    total_months += max(years_diff * 12, 6)
                    spans.append(f"{start_y} - {end_y if end_y != current_year else 'Present'}")
            except (ValueError, TypeError):
                continue

        calculated_years = round(total_months / 12.0, 1) if total_months > 0 else 0.0
        final_estimate = max(calculated_years, direct_exp)

        # Detect titles
        detected_titles = []
        for title in self.COMMON_TITLES:
            if re.search(rf"\b{re.escape(title)}\b", self.raw_text, re.IGNORECASE):
                detected_titles.append(title.title())

        return {
            "estimated_years": final_estimate,
            "calculated_spans": spans,
            "direct_mention_years": direct_exp,
            "detected_titles": list(set(detected_titles))
        }

    def analyze_impact_metrics(self) -> Dict[str, Any]:
        """Identify quantifiable metrics, numbers, percentages, and dollar amounts."""
        sentences = extract_sentences(self.raw_text)
        quantified_bullets = []
        
        # Metric patterns: %, $, numbers with scale words (users, clients, requests, ms, hours)
        metric_regex = re.compile(
            r"(\b\d+(\.\d+)?%|"
            r"[\$€£₹]\s*\d+[\d,]*(\.\d+)?[kmbKMB]?|"
            r"\b\d+[\d,]*\+?\s*(?:users|clients|customers|requests|transactions|queries|services|engineers|team members|endpoints|datasets|pipeline|records)|"
            r"\b(?:reduced|increased|improved|boosted|cut|saved)\s+[^.\n]*?\b\d+)",
            re.IGNORECASE
        )

        for s in sentences:
            if metric_regex.search(s):
                quantified_bullets.append(s)

        total_bullets = len(sentences)
        quant_percentage = round((len(quantified_bullets) / max(total_bullets, 1)) * 100, 1)

        return {
            "quantified_count": len(quantified_bullets),
            "total_sentences": total_bullets,
            "quantified_ratio_pct": quant_percentage,
            "examples": quantified_bullets[:6]  # Top examples
        }

    def analyze_action_verbs(self) -> Dict[str, Any]:
        """Measure strong action verbs vs weak/passive verbs."""
        text_lower = self.raw_text.lower()
        found_strong = {}
        for category, verbs in ACTION_VERBS.items():
            cat_found = []
            for v in verbs:
                matches = len(re.findall(rf"\b{re.escape(v)}\b", text_lower))
                if matches > 0:
                    cat_found.append({"verb": v, "count": matches})
            if cat_found:
                found_strong[category] = cat_found

        total_strong_count = sum(sum(item["count"] for item in items) for items in found_strong.values())

        # Weak words
        found_weak = []
        for w in WEAK_WORDS:
            matches = len(re.findall(rf"\b{re.escape(w)}\b", text_lower))
            if matches > 0:
                found_weak.append({"phrase": w, "count": matches})

        return {
            "strong_verbs_by_category": found_strong,
            "total_strong_verbs": total_strong_count,
            "weak_words_found": found_weak,
            "weak_words_count": sum(item["count"] for item in found_weak)
        }

    def parse_all(self) -> Dict[str, Any]:
        """Run all parsers and return comprehensive resume profile."""
        return {
            "name": self.extract_name(),
            "contact": self.extract_contact_info(),
            "sections": self.extract_sections(),
            "education": self.extract_education(),
            "experience": self.estimate_experience(),
            "impact_metrics": self.analyze_impact_metrics(),
            "action_verbs": self.analyze_action_verbs()
        }
