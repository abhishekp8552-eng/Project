"""
ATS Scorer Module.
Calculates objective, transparent ATS compatibility scores out of 100
with clear category breakdowns. Zero LLM API dependency.
"""

from typing import Dict, Any, List


class ATSScorer:
    """Calculates granular ATS readiness scores based on hiring benchmarks."""

    @staticmethod
    def calculate_score(parsed_data: Dict[str, Any], skills_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Evaluate resume against 5 standard ATS pillars:
        1. Section Completeness (20 pts)
        2. Impact & Quantifiable Metrics (25 pts)
        3. Action Verbs & Power Words (20 pts)
        4. Skills Depth & Taxonomy (20 pts)
        5. Length & Readability (15 pts)
        Total: 100 pts
        """
        breakdown = {}

        # ----------------------------------------------------
        # 1. Section Completeness (Max 20)
        # ----------------------------------------------------
        sec_score = 0
        contact = parsed_data.get("contact", {})
        sections = parsed_data.get("sections", {})

        # Contact info completeness (Max 5)
        if contact.get("email"):
            sec_score += 2
        if contact.get("phone"):
            sec_score += 1.5
        if contact.get("linkedin") or contact.get("github") or contact.get("portfolio"):
            sec_score += 1.5

        # Key Sections (Max 15)
        if sections.get("Experience", {}).get("present"):
            sec_score += 4
        if sections.get("Education", {}).get("present") or parsed_data.get("education", {}).get("has_education"):
            sec_score += 3
        if sections.get("Skills", {}).get("present") or skills_data.get("total_count", 0) >= 5:
            sec_score += 4
        if sections.get("Summary", {}).get("present"):
            sec_score += 2
        if sections.get("Projects", {}).get("present") or sections.get("Certifications", {}).get("present"):
            sec_score += 2

        sec_score = min(round(sec_score, 1), 20.0)
        breakdown["sections"] = {
            "score": sec_score,
            "max": 20,
            "percentage": round((sec_score / 20.0) * 100, 1),
            "label": "Sections & Contact Info"
        }

        # ----------------------------------------------------
        # 2. Impact & Quantifiable Metrics (Max 25)
        # ----------------------------------------------------
        metrics = parsed_data.get("impact_metrics", {})
        quant_count = metrics.get("quantified_count", 0)
        quant_ratio = metrics.get("quantified_ratio_pct", 0.0)

        # Baseline: 1 metric = 10 pts, 3 metrics = 18 pts, 5+ metrics = 25 pts
        if quant_count >= 5:
            impact_score = 25.0
        elif quant_count >= 3:
            impact_score = 20.0
        elif quant_count >= 2:
            impact_score = 15.0
        elif quant_count == 1:
            impact_score = 10.0
        else:
            impact_score = 2.0  # minimal baseline

        # Bonus for good ratio
        if quant_ratio > 30:
            impact_score = min(impact_score + 2.0, 25.0)

        breakdown["impact"] = {
            "score": round(impact_score, 1),
            "max": 25,
            "percentage": round((impact_score / 25.0) * 100, 1),
            "label": "Quantified Impact & Metrics",
            "metric_count": quant_count
        }

        # ----------------------------------------------------
        # 3. Action Verbs & Power Words (Max 20)
        # ----------------------------------------------------
        verbs = parsed_data.get("action_verbs", {})
        strong_count = verbs.get("total_strong_verbs", 0)
        weak_count = verbs.get("weak_words_count", 0)

        if strong_count >= 12:
            verb_score = 20.0
        elif strong_count >= 8:
            verb_score = 17.0
        elif strong_count >= 5:
            verb_score = 14.0
        elif strong_count >= 2:
            verb_score = 10.0
        else:
            verb_score = 4.0

        # Penalty for passive weak filler phrases
        penalty = min(weak_count * 1.5, 6.0)
        verb_score = max(round(verb_score - penalty, 1), 0.0)

        breakdown["action_verbs"] = {
            "score": verb_score,
            "max": 20,
            "percentage": round((verb_score / 20.0) * 100, 1),
            "label": "Action Verbs & Phrasing",
            "strong_verbs_count": strong_count,
            "weak_words_count": weak_count
        }

        # ----------------------------------------------------
        # 4. Skills Depth & Diversity (Max 20)
        # ----------------------------------------------------
        total_skills = skills_data.get("total_count", 0)
        cat_count = len(skills_data.get("categorized", {}))

        # Base skill count score (Max 12)
        if total_skills >= 18:
            skill_base = 12.0
        elif total_skills >= 12:
            skill_base = 10.0
        elif total_skills >= 7:
            skill_base = 7.0
        elif total_skills >= 3:
            skill_base = 4.0
        else:
            skill_base = 1.0

        # Category breadth score (Max 8)
        if cat_count >= 5:
            breadth = 8.0
        elif cat_count >= 3:
            breadth = 6.0
        elif cat_count >= 2:
            breadth = 4.0
        else:
            breadth = 2.0

        skills_score = min(round(skill_base + breadth, 1), 20.0)
        breakdown["skills_depth"] = {
            "score": skills_score,
            "max": 20,
            "percentage": round((skills_score / 20.0) * 100, 1),
            "label": "Technical Skills Depth & Diversity",
            "skill_count": total_skills,
            "categories_covered": cat_count
        }

        # ----------------------------------------------------
        # 5. Length & Readability (Max 15)
        # ----------------------------------------------------
        raw_text = parsed_data.get("raw_text", "")
        word_count = len(raw_text.split())

        if 400 <= word_count <= 950:
            readability_score = 15.0  # ideal single or 2-page tech resume
        elif 300 <= word_count < 400 or 950 < word_count <= 1300:
            readability_score = 12.0
        elif 200 <= word_count < 300 or 1300 < word_count <= 1800:
            readability_score = 9.0
        elif word_count < 200:
            readability_score = 4.0  # too sparse
        else:
            readability_score = 6.0  # excessively lengthy

        breakdown["readability"] = {
            "score": readability_score,
            "max": 15,
            "percentage": round((readability_score / 15.0) * 100, 1),
            "label": "Length, Structure & ATS Parseability",
            "word_count": word_count
        }

        # ----------------------------------------------------
        # Total Overall ATS Score
        # ----------------------------------------------------
        total_score = round(
            sec_score + impact_score + verb_score + skills_score + readability_score,
            1
        )
        total_score = min(max(total_score, 0.0), 100.0)

        # Rating Tier
        if total_score >= 85:
            rating = "Excellent"
            grade = "A+"
            badge_color = "success"
        elif total_score >= 70:
            rating = "Good (Competitive)"
            grade = "B"
            badge_color = "primary"
        elif total_score >= 55:
            rating = "Fair (Needs Polish)"
            grade = "C"
            badge_color = "warning"
        else:
            rating = "Needs Significant Improvement"
            grade = "D"
            badge_color = "danger"

        return {
            "total_score": total_score,
            "rating": rating,
            "grade": grade,
            "badge_color": badge_color,
            "breakdown": breakdown
        }
