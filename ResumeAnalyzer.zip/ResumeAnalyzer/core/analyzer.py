"""
Unified Resume Analyzer Engine.
Orchestrates text extraction, parsing, skill identification, ATS scoring,
and job description matching into a single cohesive pipeline.
100% offline, zero LLM API key required.
"""

from typing import Dict, Any, Optional
from core.extractor import ResumeExtractor
from core.cleaner import normalize_text
from core.parser import ResumeParser
from core.skills_matcher import SkillsMatcher
from core.ats_scorer import ATSScorer
from core.jd_matcher import JobDescriptionMatcher
from core.feedback_generator import FeedbackGenerator


class ResumeAnalyzerEngine:
    """End-to-end analyzer engine for resumes and job descriptions."""

    def __init__(self):
        self.skills_matcher = SkillsMatcher()
        self.jd_matcher = JobDescriptionMatcher()

    def analyze(self, resume_path: Optional[str] = None, resume_text: Optional[str] = None, jd_text: Optional[str] = None) -> Dict[str, Any]:
        """
        Runs the full analysis pipeline.
        Accepts either a resume file path (PDF/DOCX/TXT) or raw text.
        Optionally accepts job description text.
        """
        extraction_metadata = {}
        raw_text = ""

        # 1. Text Extraction
        if resume_path:
            raw_text, extraction_metadata = ResumeExtractor.extract(resume_path)
        elif resume_text:
            raw_text = resume_text
            extraction_metadata = {
                "file_type": "Pasted Text",
                "char_count": len(raw_text),
                "word_count": len(raw_text.split()),
                "is_scanned": False
            }
        else:
            return {"error": "No resume file or text provided."}

        if not raw_text.strip():
            error_msg = extraction_metadata.get(
                "error",
                "Could not extract readable text from the resume. If this is a scanned PDF image, please use a text-based PDF or DOCX file."
            )
            return {
                "error": error_msg,
                "metadata": extraction_metadata
            }

        # 2. Text Normalization
        cleaned_text = normalize_text(raw_text)

        # 3. Information Extraction / Structural Parsing
        parser = ResumeParser(cleaned_text)
        parsed_data = parser.parse_all()
        parsed_data["raw_text"] = cleaned_text

        # 4. Skills Extraction & Categorization
        skills_data = self.skills_matcher.extract_skills(cleaned_text)

        # 5. Objective ATS Scoring
        ats_score = ATSScorer.calculate_score(parsed_data, skills_data)

        # 6. Job Description Matching (if JD provided)
        jd_match_result = None
        if jd_text and jd_text.strip():
            clean_jd = normalize_text(jd_text)
            candidate_exp = parsed_data.get("experience", {}).get("estimated_years", 0.0)
            jd_match_result = self.jd_matcher.match(
                resume_text=cleaned_text,
                jd_text=clean_jd,
                candidate_exp_years=candidate_exp
            )

        # 7. Actionable Feedback & Recommendation Generation
        feedback = FeedbackGenerator.generate_feedback(
            parsed_data=parsed_data,
            skills_data=skills_data,
            ats_score=ats_score,
            jd_match=jd_match_result
        )

        return {
            "success": True,
            "metadata": extraction_metadata,
            "profile": {
                "name": parsed_data["name"],
                "contact": parsed_data["contact"],
                "experience": parsed_data["experience"],
                "education": parsed_data["education"],
                "sections": parsed_data["sections"]
            },
            "skills": skills_data,
            "impact_metrics": parsed_data["impact_metrics"],
            "action_verbs": parsed_data["action_verbs"],
            "ats_score": ats_score,
            "jd_match": jd_match_result,
            "feedback": feedback,
            "resume_text_preview": cleaned_text[:1200] + ("..." if len(cleaned_text) > 1200 else "")
        }
