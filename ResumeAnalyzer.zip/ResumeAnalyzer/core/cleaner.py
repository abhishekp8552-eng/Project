"""
Text Cleaning and Normalization Module.
Preprocesses resume and job description text for robust NLP and matching.
"""

import re
import unicodedata
from typing import List

# Complete standard English stopwords list (100% offline, zero network dependencies)
STOPWORDS = {
    "a", "about", "above", "after", "again", "against", "all", "am", "an", "and",
    "any", "are", "aren't", "as", "at", "be", "because", "been", "before", "being",
    "below", "between", "both", "but", "by", "can't", "cannot", "could", "couldn't",
    "did", "didn't", "do", "does", "doesn't", "doing", "don't", "down", "during",
    "each", "few", "for", "from", "further", "had", "hadn't", "has", "hasn't",
    "have", "haven't", "having", "he", "he'd", "he'll", "he's", "her", "here",
    "here's", "hers", "herself", "him", "himself", "his", "how", "how's", "i",
    "i'd", "i'll", "i'm", "i've", "if", "in", "into", "is", "isn't", "it", "it's",
    "its", "itself", "let's", "me", "more", "most", "mustn't", "my", "myself",
    "no", "nor", "not", "of", "off", "on", "once", "only", "or", "other", "ought",
    "our", "ours", "ourselves", "out", "over", "own", "same", "shan't", "she",
    "she'd", "she'll", "she's", "should", "shouldn't", "so", "some", "such",
    "than", "that", "that's", "the", "their", "theirs", "them", "themselves",
    "then", "there", "there's", "these", "they", "they'd", "they'll", "they're",
    "they've", "this", "those", "through", "to", "too", "under", "until", "up",
    "very", "was", "wasn't", "we", "we'd", "we'll", "we're", "we've", "were",
    "weren't", "what", "what's", "when", "when's", "where", "where's", "which",
    "while", "who", "who's", "whom", "why", "why's", "with", "won't", "would",
    "wouldn't", "you", "you'd", "you'll", "you're", "you've", "your", "yours",
    "yourself", "yourselves"
}


def normalize_text(text: str) -> str:
    """Normalize unicode characters, quotes, dashes, and extra whitespace."""
    if not text:
        return ""
    # Unicode normalize
    text = unicodedata.normalize("NFKD", text)
    # Replace non-standard bullets and hyphens
    text = re.sub(r"[\u2022\u2023\u25E6\u2043\u2219\u25AA\u25CF\u25CB\u25A0]", "\n- ", text)
    # Normalize curly quotes and em dashes
    text = re.sub(r"[\u2018\u2019]", "'", text)
    text = re.sub(r"[\u201C\u201D]", '"', text)
    text = re.sub(r"[\u2013\u2014]", "-", text)
    # Remove control characters except newlines and tabs
    text = "".join(ch for ch in text if ch == "\n" or ch == "\t" or not unicodedata.category(ch).startswith("C"))
    # Collapse multiple consecutive blank lines
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def extract_sentences(text: str) -> List[str]:
    """Split text into sentences or bullet points."""
    lines = [line.strip() for line in text.split("\n") if line.strip()]
    sentences = []
    for line in lines:
        # Check if line contains multiple sentences
        sub_sentences = re.split(r"(?<=[.!?])\s+(?=[A-Z0-9])", line)
        for s in sub_sentences:
            cleaned = s.strip(" -•*")
            if len(cleaned) > 5:
                sentences.append(cleaned)
    return sentences


def tokenize(text: str, remove_stopwords: bool = True) -> List[str]:
    """Tokenize text into lowercase alphanumeric words."""
    words = re.findall(r"\b[a-zA-Z0-9+#.-]+\b", text.lower())
    if remove_stopwords:
        return [w for w in words if w not in STOPWORDS and len(w) > 1]
    return words
