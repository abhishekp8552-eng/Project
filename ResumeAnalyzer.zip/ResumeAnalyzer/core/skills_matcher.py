"""
Skills Matching Engine.
Accurately identifies technical & soft skills in resume and JD text using
phrase boundary regexes and domain taxonomy matching.
"""

import re
from typing import Dict, List, Set, Any
from core.skills_database import SKILLS_TAXONOMY


class SkillsMatcher:
    """Matches and categorizes skills from text."""

    def __init__(self, taxonomy: Dict[str, List[str]] = None):
        self.taxonomy = taxonomy or SKILLS_TAXONOMY
        self._compiled_patterns = self._build_patterns()

    def _build_patterns(self) -> Dict[str, Dict[str, re.Pattern]]:
        """Pre-compile regex patterns for fast, boundary-accurate matching."""
        compiled = {}
        for category, skills in self.taxonomy.items():
            compiled[category] = {}
            for skill in skills:
                escaped = re.escape(skill)
                # Handle special language single-letters like "c" or "r" carefully
                if skill in ["c", "r"]:
                    pattern = re.compile(
                        rf"(?:\b|\s)(?:language\s+)?{escaped}(?:/|\s*,\s*|\s+programming|\s+developer|\s+language|\s+code|\b)",
                        re.IGNORECASE
                    )
                # Handle c++ and c#
                elif skill in ["c++", "c#", ".net"]:
                    pattern = re.compile(
                        rf"(?:^|[\s,;/()]){escaped}(?:[\s,;/()]|$)",
                        re.IGNORECASE
                    )
                # General skill pattern with standard boundaries
                else:
                    pattern = re.compile(
                        rf"\b{escaped}\b",
                        re.IGNORECASE
                    )
                compiled[category][skill] = pattern
        return compiled

    def extract_skills(self, text: str) -> Dict[str, Any]:
        """
        Extract all recognized skills from text.
        Returns:
            - 'all_skills': list of skill names found
            - 'categorized': dict mapping category -> list of skills found
            - 'frequencies': dict mapping skill name -> occurrence count
            - 'total_count': total number of unique skills matched
        """
        if not text:
            return {
                "all_skills": [],
                "categorized": {},
                "frequencies": {},
                "total_count": 0
            }

        categorized = {}
        frequencies = {}
        all_skills_set = set()

        text_lower = text.lower()

        for category, patterns in self._compiled_patterns.items():
            matched_in_cat = []
            for skill, pattern in patterns.items():
                matches = pattern.findall(text)
                if matches:
                    count = len(matches)
                    frequencies[skill] = count
                    matched_in_cat.append(skill)
                    all_skills_set.add(skill)

            if matched_in_cat:
                categorized[category] = sorted(matched_in_cat)

        return {
            "all_skills": sorted(list(all_skills_set)),
            "categorized": categorized,
            "frequencies": frequencies,
            "total_count": len(all_skills_set)
        }

    def compare_skills(self, resume_skills: List[str], jd_skills: List[str]) -> Dict[str, Any]:
        """
        Compare skills between Resume and Job Description.
        Returns matched skills, missing skills, and match percentage.
        """
        resume_set = set(s.lower() for s in resume_skills)
        jd_set = set(s.lower() for s in jd_skills)

        matched = sorted(list(resume_set.intersection(jd_set)))
        missing = sorted(list(jd_set - resume_set))
        extra = sorted(list(resume_set - jd_set))

        match_pct = round((len(matched) / len(jd_set) * 100), 1) if jd_set else 100.0

        return {
            "matched_skills": matched,
            "missing_skills": missing,
            "extra_skills": extra,
            "matched_count": len(matched),
            "missing_count": len(missing),
            "jd_total_count": len(jd_set),
            "match_percentage": match_pct
        }
