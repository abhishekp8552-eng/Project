"""
Text Extractor for Resume Analyzer.
Extracts clean, structured text from PDF, DOCX, and TXT files without external APIs.
"""

import os
from typing import Tuple, Dict, Any
from pypdf import PdfReader
from docx import Document


class ResumeExtractor:
    """Extracts raw text and metadata from PDF, DOCX, and TXT resumes."""

    @staticmethod
    def extract_from_pdf(file_path: str) -> Tuple[str, Dict[str, Any]]:
        """Extract text and metadata from a PDF file."""
        text_pages = []
        page_count = 0
        try:
            reader = PdfReader(file_path)
            page_count = len(reader.pages)
            for page_idx, page in enumerate(reader.pages):
                extracted = page.extract_text()
                if extracted:
                    text_pages.append(extracted.strip())
        except Exception as e:
            return "", {"error": f"Failed to extract PDF: {str(e)}", "pages": page_count}

        full_text = "\n\n".join(text_pages)
        metadata = {
            "file_type": "PDF",
            "page_count": page_count,
            "char_count": len(full_text),
            "word_count": len(full_text.split()),
            "is_scanned": len(full_text.strip()) < 50 and page_count > 0
        }
        return full_text, metadata

    @staticmethod
    def extract_from_docx(file_path: str) -> Tuple[str, Dict[str, Any]]:
        """Extract text and metadata from a DOCX file."""
        paragraphs = []
        try:
            doc = Document(file_path)
            for p in doc.paragraphs:
                if p.text.strip():
                    paragraphs.append(p.text.strip())
            
            # Also extract text from tables if any
            for table in doc.tables:
                for row in table.rows:
                    row_texts = [cell.text.strip() for cell in row.cells if cell.text.strip()]
                    if row_texts:
                        paragraphs.append(" | ".join(row_texts))
        except Exception as e:
            return "", {"error": f"Failed to extract DOCX: {str(e)}", "paragraphs": 0}

        full_text = "\n".join(paragraphs)
        metadata = {
            "file_type": "DOCX",
            "paragraph_count": len(paragraphs),
            "char_count": len(full_text),
            "word_count": len(full_text.split()),
            "is_scanned": False
        }
        return full_text, metadata

    @staticmethod
    def extract_from_txt(file_path: str) -> Tuple[str, Dict[str, Any]]:
        """Extract text from plain text or markdown files."""
        text = ""
        for encoding in ["utf-8", "latin-1", "cp1252"]:
            try:
                with open(file_path, "r", encoding=encoding) as f:
                    text = f.read()
                break
            except UnicodeDecodeError:
                continue

        metadata = {
            "file_type": "TXT",
            "char_count": len(text),
            "word_count": len(text.split()),
            "is_scanned": False
        }
        return text, metadata

    @classmethod
    def extract(cls, file_path_or_stream: str) -> Tuple[str, Dict[str, Any]]:
        """Auto-detect file format and extract text."""
        ext = os.path.splitext(file_path_or_stream)[1].lower()
        if ext == ".pdf":
            return cls.extract_from_pdf(file_path_or_stream)
        elif ext in [".docx", ".doc"]:
            return cls.extract_from_docx(file_path_or_stream)
        elif ext in [".txt", ".md", ".rtf"]:
            return cls.extract_from_txt(file_path_or_stream)
        else:
            # Fallback attempt plain text
            return cls.extract_from_txt(file_path_or_stream)
