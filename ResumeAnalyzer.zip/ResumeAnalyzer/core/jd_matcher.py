"""
Job Description Matching Engine.
Compares resumes against job descriptions using TF-IDF Vectorization,
Cosine Similarity, Skill Overlap, and Experience Alignment.
100% offline, zero LLM API calls needed.
"""

import re
from typing import Dict, Any, List
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from core.skills_matcher import SkillsMatcher
from core.cleaner import tokenize


class JobDescriptionMatcher:
    """Computes alignment, keyword gap, and ATS compatibility between a Resume and JD."""

    def __init__(self):
        self.skills_matcher = SkillsMatcher()

    def extract_jd_experience_requirement(self, jd_text: str) -> float:
        """Extract minimum years of experience requested in the job description."""
        patterns = [
            r"(\d+(?:\.\d+)?)\s*\+?\s*(?:to\s*\d+\s*)?(?:years|yrs)(?:\s+of)?\s+(?:experience|exp)",
            r"(?:minimum|at least)\s+(\d+(?:\.\d+)?)\s*(?:years|yrs)",
            r"(\d+(?:\.\d+)?)\s*(?:years|yrs)(?:\s+minimum|\s+required)"
        ]
        found = []
        for p in patterns:
            matches = re.findall(p, jd_text, re.IGNORECASE)
            for m in matches:
                try:
                    found.append(float(m))
                except ValueError:
                    pass
        return max(found) if found else 0.0

    def calculate_tfidf_similarity(self, resume_text: str, jd_text: str) -> float:
        """Calculate cosine similarity using TF-IDF unigrams and bigrams."""
        if not resume_text.strip() or not jd_text.strip():
            return 0.0

        try:
            vectorizer = TfidfVectorizer(
                stop_words="english",
                ngram_range=(1, 2),
                max_features=5000
            )
            tfidf_matrix = vectorizer.fit_transform([resume_text, jd_text])
            sim = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
            return round(float(sim) * 100, 2)
        except Exception:
            return 0.0

    def extract_top_jd_keywords(self, jd_text: str, top_n: int = 15) -> List[Dict[str, Any]]:
        """Identify high-priority keywords from the job description using TF-IDF scores."""
        if not jd_text.strip():
            return []

        try:
            vectorizer = TfidfVectorizer(
                stop_words="english",
                ngram_range=(1, 2),
                max_features=200
            )
            tfidf_matrix = vectorizer.fit_transform([jd_text])
            feature_names = vectorizer.get_feature_names_out()
            scores = tfidf_matrix.toarray()[0]

            scored_words = sorted(
                zip(feature_names, scores),
                key=lambda x: x[1],
                reverse=True
            )
            return [{"term": term, "weight": round(score, 3)} for term, score in scored_words[:top_n]]
        except Exception:
            return []

    def match(self, resume_text: str, jd_text: str, candidate_exp_years: float = 0.0) -> Dict[str, Any]:
        """
        Comprehensive comparison between resume and job description.
        Returns:
            - overall_match_score (0 - 100)
            - tfidf_similarity (0 - 100)
            - skill_match_score (0 - 100)
            - matched_skills, missing_skills, extra_skills
            - required_experience, candidate_experience, meets_experience
            - missing_important_keywords
        """
        if not jd_text.strip():
            return {"error": "Job description text is empty"}

        # 1. TF-IDF Similarity
        tfidf_score = self.calculate_tfidf_similarity(resume_text, jd_text)

        # 2. Skill Comparison
        resume_skills_data = self.skills_matcher.extract_skills(resume_text)
        jd_skills_data = self.skills_matcher.extract_skills(jd_text)

        skills_comp = self.skills_matcher.compare_skills(
            resume_skills_data["all_skills"],
            jd_skills_data["all_skills"]
        )

        skill_match_pct = skills_comp["match_percentage"]

        # 3. Experience Requirement
        jd_req_exp = self.extract_jd_experience_requirement(jd_text)
        meets_exp = True
        exp_score = 100.0
        if jd_req_exp > 0:
            if candidate_exp_years >= jd_req_exp:
                exp_score = 100.0
                meets_exp = True
            elif candidate_exp_years > 0:
                exp_score = round(min((candidate_exp_years / jd_req_exp) * 100, 100.0), 1)
                meets_exp = False
            else:
                exp_score = 60.0  # unknown or unstated experience
                meets_exp = False

        # 4. Top JD Keywords Gap
        top_jd_keywords = self.extract_top_jd_keywords(jd_text, top_n=20)
        resume_lower = resume_text.lower()
        missing_keywords = []
        for kw in top_jd_keywords:
            term = kw["term"]
            if term not in resume_lower:
                missing_keywords.append(term)

        # 5. Composite Match Score
        # TF-IDF (35%) + Skill Match (45%) + Experience Alignment (20%)
        # Note: TF-IDF cosine similarity for text is usually between 20-70% even for good matches,
        # so we scale it using standard text similarity normalization.
        normalized_tfidf = min(tfidf_score * 1.5, 100.0)
        
        overall_score = round(
            (0.45 * skill_match_pct) +
            (0.35 * normalized_tfidf) +
            (0.20 * exp_score),
            1
        )
        overall_score = min(max(overall_score, 0.0), 100.0)

        return {
            "overall_match_score": overall_score,
            "tfidf_similarity": tfidf_score,
            "normalized_tfidf": round(normalized_tfidf, 1),
            "skill_match_percentage": skill_match_pct,
            "matched_skills": skills_comp["matched_skills"],
            "missing_skills": skills_comp["missing_skills"],
            "extra_skills": skills_comp["extra_skills"][:10],
            "jd_skills_count": skills_comp["jd_total_count"],
            "matched_skills_count": skills_comp["matched_count"],
            "missing_skills_count": skills_comp["missing_count"],
            "required_experience_years": jd_req_exp,
            "candidate_experience_years": candidate_exp_years,
            "meets_experience_requirement": meets_exp,
            "missing_top_keywords": missing_keywords[:10]
        }
