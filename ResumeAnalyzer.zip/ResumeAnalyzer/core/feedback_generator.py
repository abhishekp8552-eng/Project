"""
Feedback and Recommendation Generator.
Produces prioritized, actionable tips, XYZ-formula suggestions,
and ATS-optimization advice without requiring LLMs.
"""

from typing import Dict, Any, List


class FeedbackGenerator:
    """Generates structured hiring & ATS recommendations."""

    @staticmethod
    def generate_feedback(parsed_data: Dict[str, Any], skills_data: Dict[str, Any], ats_score: Dict[str, Any], jd_match: Dict[str, Any] = None) -> Dict[str, Any]:
        critical = []
        improvements = []
        strengths = []

        contact = parsed_data.get("contact", {})
        sections = parsed_data.get("sections", {})
        metrics = parsed_data.get("impact_metrics", {})
        verbs = parsed_data.get("action_verbs", {})
        breakdown = ats_score.get("breakdown", {})

        # ----------------------------------------------------
        # 1. Contact Info & Header Checks
        # ----------------------------------------------------
        if not contact.get("email"):
            critical.append({
                "category": "Contact Information",
                "issue": "No email address detected",
                "recommendation": "Add a professional email address (e.g., firstname.lastname@gmail.com) prominently at the top."
            })
        if not contact.get("phone"):
            critical.append({
                "category": "Contact Information",
                "issue": "No phone number found",
                "recommendation": "Include a standard phone number with country/area code so recruiters can contact you."
            })
        if not contact.get("linkedin"):
            improvements.append({
                "category": "Online Presence",
                "issue": "No LinkedIn profile URL found",
                "recommendation": "Add your customized LinkedIn profile link (e.g., linkedin.com/in/yourname). Recruiters check this for 90%+ of technical roles."
            })
        else:
            strengths.append("LinkedIn profile link is included and accessible.")

        if not contact.get("github") and any(cat in skills_data.get("categorized", {}) for cat in ["Programming Languages", "Frontend & Web", "Backend & APIs"]):
            improvements.append({
                "category": "Technical Portfolio",
                "issue": "No GitHub link detected for developer profile",
                "recommendation": "Include your GitHub profile (github.com/username) to showcase open-source contributions and personal code repos."
            })
        elif contact.get("github"):
            strengths.append("GitHub profile link included to showcase technical work.")

        # ----------------------------------------------------
        # 2. Section Completeness Checks
        # ----------------------------------------------------
        if not sections.get("Experience", {}).get("present"):
            critical.append({
                "category": "Resume Sections",
                "issue": "Work Experience section header missing or unparsed",
                "recommendation": "Use a clear, standard section header such as 'Work Experience' or 'Professional Experience'."
            })
        else:
            strengths.append("Standard 'Work Experience' section is clearly defined.")

        if not sections.get("Education", {}).get("present") and not parsed_data.get("education", {}).get("has_education"):
            critical.append({
                "category": "Resume Sections",
                "issue": "No Education section found",
                "recommendation": "Add an 'Education' section listing your degree, institution, and graduation year."
            })
        else:
            strengths.append("Education background and qualifications are recognized.")

        if not sections.get("Skills", {}).get("present"):
            improvements.append({
                "category": "Resume Sections",
                "issue": "Dedicated Skills section is missing",
                "recommendation": "Create a distinct 'Technical Skills' section grouped by category (e.g., Languages, Frameworks, Cloud, Databases)."
            })

        if not sections.get("Summary", {}).get("present"):
            improvements.append({
                "category": "Resume Sections",
                "issue": "No Professional Summary header found",
                "recommendation": "Include a concise 2-3 line Professional Summary at the top highlighting your years of experience, core tech stack, and top achievement."
            })

        # ----------------------------------------------------
        # 3. Quantifiable Impact & Google XYZ Formula
        # ----------------------------------------------------
        quant_count = metrics.get("quantified_count", 0)
        if quant_count == 0:
            critical.append({
                "category": "Impact & Achievements",
                "issue": "No measurable metrics or numbers found in bullet points",
                "recommendation": "Use Google's XYZ formula: 'Accomplished [X] as measured by [Y], by doing [Z]'. Example: 'Reduced API latency by 45% by implementing Redis caching and indexing database queries.'"
            })
        elif quant_count < 3:
            improvements.append({
                "category": "Impact & Achievements",
                "issue": f"Only {quant_count} bullet points contain quantified metrics",
                "recommendation": "Aim for at least 4-6 bullet points containing numbers, percentages (%), cost savings ($), or scale (users/requests handled)."
            })
        else:
            strengths.append(f"Strong use of data! Detected {quant_count} bullet points with measurable impact metrics.")

        # ----------------------------------------------------
        # 4. Action Verbs vs Passive Weak Phrasing
        # ----------------------------------------------------
        weak_count = verbs.get("weak_words_count", 0)
        strong_count = verbs.get("total_strong_verbs", 0)

        if weak_count > 0:
            weak_phrases = [item["phrase"] for item in verbs.get("weak_words_found", [])]
            improvements.append({
                "category": "Word Choice & Tone",
                "issue": f"Detected {weak_count} passive/weak phrase(s): {', '.join(weak_phrases[:4])}",
                "recommendation": "Replace passive phrases like 'responsible for' or 'helped with' with decisive power verbs like 'Architected', 'Spearheaded', 'Optimized', or 'Automated'."
            })

        if strong_count >= 8:
            strengths.append(f"Excellent leadership vocabulary: {strong_count} high-impact action verbs detected.")
        elif strong_count < 3:
            improvements.append({
                "category": "Word Choice & Tone",
                "issue": "Low frequency of strong action verbs",
                "recommendation": "Begin every bullet point in your Experience section with a strong past-tense action verb (e.g. Engineered, Deployed, Streamlined)."
            })

        # ----------------------------------------------------
        # 5. Skills Breadth & Taxonomy
        # ----------------------------------------------------
        total_skills = skills_data.get("total_count", 0)
        if total_skills < 6:
            critical.append({
                "category": "Technical Skills",
                "issue": f"Only {total_skills} technical skills identified",
                "recommendation": "List all relevant tools, libraries, and frameworks you have used. ATS scanners match against exact skill keywords."
            })
        elif total_skills >= 15:
            strengths.append(f"Rich technical stack: {total_skills} verified industry skills detected across multiple domains.")

        # ----------------------------------------------------
        # 6. Length & Word Count
        # ----------------------------------------------------
        word_count = breakdown.get("readability", {}).get("word_count", 0)
        if word_count < 250 and word_count > 0:
            critical.append({
                "category": "Resume Length",
                "issue": f"Resume is very brief ({word_count} words)",
                "recommendation": "Expand upon your project responsibilities and accomplishments. A standard 1-page tech resume typically has 400 - 700 words."
            })
        elif word_count > 1200:
            improvements.append({
                "category": "Resume Length",
                "issue": f"Resume is quite long ({word_count} words)",
                "recommendation": "Consider condensing older roles to 2-3 bullet points to keep the resume concise and recruiter-friendly (1-2 pages maximum)."
            })
        else:
            strengths.append(f"Optimal resume length ({word_count} words) for ATS parsing and human readability.")

        # ----------------------------------------------------
        # 7. Job Description Matching (If JD provided)
        # ----------------------------------------------------
        if jd_match and not jd_match.get("error"):
            missing_skills = jd_match.get("missing_skills", [])
            missing_keywords = jd_match.get("missing_top_keywords", [])
            meets_exp = jd_match.get("meets_experience_requirement", True)
            req_exp = jd_match.get("required_experience_years", 0)
            cand_exp = jd_match.get("candidate_experience_years", 0)

            if missing_skills:
                critical.append({
                    "category": "Job Description Alignment",
                    "issue": f"Missing {len(missing_skills)} required skills from the job posting",
                    "recommendation": f"If you have experience with these skills, add them to your resume: {', '.join(missing_skills[:8])}."
                })
            else:
                strengths.append("100% skill match with all key technical requirements from the Job Description!")

            if not meets_exp and req_exp > 0:
                improvements.append({
                    "category": "Experience Requirement",
                    "issue": f"JD requests {req_exp} years; detected ~{cand_exp} years on resume",
                    "recommendation": "Ensure your dates of employment are clearly formatted (e.g. Month Year - Month Year) so all relevant experience is credited."
                })

            if missing_keywords:
                improvements.append({
                    "category": "Keyword Optimization",
                    "issue": f"High-frequency JD terms absent: {', '.join(missing_keywords[:6])}",
                    "recommendation": "Naturally incorporate these terms into your project descriptions and summary to maximize ATS keyword scoring."
                })

        return {
            "critical_fixes": critical,
            "improvements": improvements,
            "strengths": strengths,
            "total_issues": len(critical) + len(improvements)
        }
