"""
Skills Database and Taxonomy for Resume Analyzer
Contains over 1,200+ skills categorized into domains, plus action verbs and metrics patterns.
100% self-contained without needing any external API or LLM.
"""

SKILLS_TAXONOMY = {
    "Programming Languages": [
        "python", "java", "c++", "c#", "c", "javascript", "typescript", "go", "golang",
        "rust", "ruby", "php", "swift", "kotlin", "scala", "r", "dart", "perl", "haskell",
        "elixir", "clojure", "lua", "shell", "bash", "powershell", "matlab", "assembly",
        "objective-c", "groovy", "vba", "solidity", "erlang", "f#"
    ],
    "Frontend & Web": [
        "react", "react.js", "next.js", "angular", "angularjs", "vue", "vue.js", "nuxt.js",
        "svelte", "sveltekit", "html", "html5", "css", "css3", "sass", "scss", "less",
        "tailwind", "tailwind css", "bootstrap", "material ui", "chakra ui", "shadcn",
        "redux", "redux toolkit", "mobx", "zustand", "recoil", "jquery", "webpack", "vite",
        "babel", "gulp", "npm", "yarn", "pnpm", "responsive design", "web accessibility",
        "wcag", "spa", "pwa", "websocket", "webrtc"
    ],
    "Backend & APIs": [
        "node.js", "express", "express.js", "nestjs", "fastify", "django", "flask",
        "fastapi", "spring", "spring boot", "asp.net", "asp.net core", ".net", ".net core",
        "ruby on rails", "laravel", "symfony", "gin", "fiber", "actix", "rocket",
        "graphql", "rest api", "restful api", "restful apis", "grpc", "soap",
        "microservices", "service-oriented architecture", "soa", "monolith",
        "event-driven architecture", "message queues", "rabbitmq", "kafka", "apache kafka",
        "celery", "sidekiq", "pub/sub", "zeromq"
    ],
    "Databases & Storage": [
        "sql", "postgresql", "postgres", "mysql", "mariadb", "sqlite", "oracle", "mssql",
        "microsoft sql server", "mongodb", "redis", "cassandra", "couchdb", "dynamodb",
        "neo4j", "arangodb", "elasticsearch", "opensearch", "solr", "firebase", "supabase",
        "planetscale", "prisma", "hibernate", "entity framework", "sqlalchemy", "typeorm",
        "database indexing", "query optimization", "sharding", "replication", "acid"
    ],
    "Cloud & DevOps": [
        "aws", "amazon web services", "ec2", "s3", "lambda", "ecs", "eks", "rds", "cloudformation",
        "route53", "azure", "azure devops", "azure functions", "gcp", "google cloud platform",
        "cloud run", "app engine", "docker", "kubernetes", "k8s", "helm", "terraform",
        "ansible", "puppet", "chef", "vagrant", "ci/cd", "continuous integration",
        "continuous deployment", "jenkins", "github actions", "gitlab ci", "circleci",
        "travis ci", "argo cd", "prometheus", "grafana", "datadog", "new relic", "splunk",
        "elk stack", "nginx", "apache", "caddy", "linux", "unix", "ubuntu", "centos",
        "debian", "red hat", "alpine", "load balancing", "reverse proxy"
    ],
    "AI, Machine Learning & Data Science": [
        "machine learning", "deep learning", "artificial intelligence", "nlp",
        "natural language processing", "computer vision", "cv", "reinforcement learning",
        "supervised learning", "unsupervised learning", "data science", "data analysis",
        "data mining", "predictive modeling", "statistical analysis", "pytorch", "tensorflow",
        "keras", "scikit-learn", "pandas", "numpy", "scipy", "statsmodels", "opencv",
        "nltk", "spacy", "huggingface", "transformers", "bert", "gpt", "llm",
        "large language models", "prompt engineering", "langchain", "llamaindex", "rag",
        "vector database", "faiss", "chromadb", "pinecone", "weaviate", "qdrant",
        "xgboost", "lightgbm", "catboost", "random forest", "svm", "linear regression",
        "logistic regression", "pca", "kmeans", "time series forecasting", "arima",
        "prophet", "neural networks", "cnn", "rnn", "lstm", "gan", "diffusion models",
        "mlops", "mlflow", "kubeflow", "wandb", "dvc"
    ],
    "Big Data & Data Engineering": [
        "big data", "hadoop", "hdfs", "mapreduce", "spark", "apache spark", "pyspark",
        "hive", "pig", "spark streaming", "flink", "apache flink", "airflow",
        "apache airflow", "presto", "trino", "snowflake", "databricks", "bigquery",
        "redshift", "synapse", "etl", "elt", "data pipeline", "data warehouse",
        "data lake", "dbt", "talend", "ssis", "kafka streams"
    ],
    "Data Visualization & BI": [
        "tableau", "power bi", "powerbi", "looker", "metabase", "superset", "qlik",
        "matplotlib", "seaborn", "plotly", "d3.js", "chart.js", "bokeh", "dash",
        "google data studio"
    ],
    "Mobile Development": [
        "android", "ios", "react native", "flutter", "xamarin", "ionic", "swiftui",
        "jetpack compose", "mobile app development", "expo", "cocoapods", "gradle"
    ],
    "Testing & QA": [
        "unit testing", "integration testing", "e2e testing", "end-to-end testing",
        "test driven development", "tdd", "bdd", "behavior driven development",
        "pytest", "unittest", "jest", "mocha", "chai", "cypress", "selenium",
        "playwright", "puppeteer", "postman", "newman", "insomnia", "junit",
        "testng", "mockito", "locust", "jmeter", "k6", "qa automation", "manual testing"
    ],
    "Cybersecurity & Networking": [
        "cybersecurity", "information security", "infosec", "network security",
        "penetration testing", "pen testing", "vulnerability assessment", "ethical hacking",
        "owasp", "siem", "soc", "firewall", "ids", "ips", "wireshark", "nmap",
        "cryptography", "encryption", "ssl", "tls", "https", "oauth", "oauth2",
        "saml", "jwt", "iam", "zero trust", "soc 2", "iso 27001", "gdpr", "hipaa"
    ],
    "Software Architecture & Practices": [
        "system design", "software architecture", "design patterns", "clean code",
        "clean architecture", "domain driven design", "ddd", "solid principles",
        "object oriented programming", "oop", "functional programming",
        "data structures", "algorithms", "scalability", "high availability",
        "fault tolerance", "concurrency", "multithreading", "asynchronous programming",
        "caching", "cdn", "code review", "git", "github", "gitlab", "bitbucket",
        "svn", "version control"
    ],
    "Methodologies & Project Management": [
        "agile", "scrum", "kanban", "scrum master", "sprint planning", "jira",
        "confluence", "trello", "asana", "notion", "clickup", "waterfall",
        "sdlc", "software development lifecycle", "pmp", "prince2", "lean"
    ],
    "Soft Skills & Leadership": [
        "leadership", "team leadership", "mentoring", "communication",
        "cross-functional collaboration", "stakeholder management", "problem solving",
        "critical thinking", "adaptability", "time management", "conflict resolution",
        "client presentation", "public speaking", "strategic planning", "decision making",
        "negotiation", "emotional intelligence", "analytical thinking"
    ]
}

# Strong action verbs organized by category to measure impact
ACTION_VERBS = {
    "Leadership & Management": [
        "spearheaded", "orchestrated", "championed", "directed", "steered",
        "founded", "guided", "governed", "supervised", "mentored", "coached",
        "empowered", "mobilized", "fostered", "advocated", "delegated"
    ],
    "Innovation & Architecture": [
        "architected", "engineered", "pioneered", "designed", "formulated",
        "conceptualized", "devised", "invented", "modeled", "overhauled",
        "restructured", "revamped", "modernized", "revolutionized", "crafted"
    ],
    "Execution & Development": [
        "developed", "implemented", "constructed", "built", "programmed",
        "deployed", "delivered", "executed", "configured", "integrated",
        "launched", "established", "instituted", "authored", "created"
    ],
    "Optimization & Performance": [
        "optimized", "accelerated", "streamlined", "automated", "enhanced",
        "boosted", "maximized", "reduced", "minimized", "scaled",
        "consolidated", "upgraded", "refined", "mitigated", "resolved"
    ],
    "Collaboration & Communication": [
        "collaborated", "partnered", "negotiated", "facilitated", "liaised",
        "coordinated", "aligned", "presented", "published", "authored"
    ]
}

# Flat list of all strong action verbs
ALL_ACTION_VERBS = set()
for verbs in ACTION_VERBS.values():
    ALL_ACTION_VERBS.update(verbs)

# Weak words / passive filler words that lower resume strength
WEAK_WORDS = [
    "responsible for", "duties included", "tasked with", "worked on",
    "helped with", "assisted with", "handled", "participated in",
    "involved in", "familiar with", "tried to", "attempted"
]

# Standard sections in a strong ATS resume
STANDARD_SECTIONS = [
    "summary", "professional summary", "career objective", "objective",
    "experience", "work experience", "employment history", "professional experience",
    "education", "academic background", "qualifications",
    "skills", "technical skills", "core competencies", "skills & tools",
    "projects", "personal projects", "key projects", "notable projects",
    "certifications", "licenses", "certificates", "credentials",
    "awards", "honors", "achievements", "publications"
]

# Common Degrees
COMMON_DEGREES = [
    "ph.d", "phd", "doctor of philosophy", "doctorate",
    "m.tech", "mtech", "master of technology",
    "m.s", "ms", "master of science",
    "m.e", "me", "master of engineering",
    "mca", "master of computer applications",
    "mba", "master of business administration",
    "b.tech", "btech", "bachelor of technology",
    "b.e", "be", "bachelor of engineering",
    "b.s", "bs", "bachelor of science",
    "bca", "bachelor of computer applications",
    "bba", "bachelor of business administration",
    "b.a", "ba", "bachelor of arts",
    "associate degree", "diploma", "high school"
]
