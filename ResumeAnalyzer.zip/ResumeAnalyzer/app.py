import os
import sys
import tempfile

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from flask import Flask, render_template, request, jsonify, send_file
from core.analyzer import ResumeAnalyzerEngine

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024  # 16 MB max upload
ALLOWED_EXTENSIONS = {".pdf", ".docx", ".doc", ".txt", ".md"}

analyzer_engine = ResumeAnalyzerEngine()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SAMPLES_DIR = os.path.join(BASE_DIR, "samples")


def allowed_file(filename: str) -> bool:
    ext = os.path.splitext(filename)[1].lower()
    return ext in ALLOWED_EXTENSIONS


@app.route("/")
def index():
    """Main dashboard interface."""
    return render_template("index.html")


@app.route("/api/sample/<role>", methods=["GET"])
def get_sample(role: str):
    """Retrieve pre-built sample resume and job description."""
    role = role.lower()
    resume_file = None
    jd_file = None

    if role in ["swe", "software", "fullstack"]:
        resume_file = os.path.join(SAMPLES_DIR, "sample_resume_swe.txt")
        jd_file = os.path.join(SAMPLES_DIR, "sample_jd_swe.txt")
    elif role in ["ds", "data", "ml"]:
        resume_file = os.path.join(SAMPLES_DIR, "sample_resume_ds.txt")
        jd_file = os.path.join(SAMPLES_DIR, "sample_jd_ds.txt")
    else:
        return jsonify({"error": "Unknown sample role"}), 404

    resume_text = ""
    jd_text = ""

    if os.path.exists(resume_file):
        with open(resume_file, "r", encoding="utf-8") as f:
            resume_text = f.read()

    if os.path.exists(jd_file):
        with open(jd_file, "r", encoding="utf-8") as f:
            jd_text = f.read()

    return jsonify({
        "role": role,
        "resume_text": resume_text,
        "jd_text": jd_text
    })


@app.route("/api/analyze", methods=["POST"])
def analyze_endpoint():
    """Analyze uploaded resume file or pasted text against optional JD."""
    resume_text = request.form.get("resume_text", "").strip()
    jd_text = request.form.get("jd_text", "").strip()
    file = request.files.get("resume_file")

    temp_path = None
    try:
        if file and file.filename:
            ext = os.path.splitext(file.filename)[1].lower()
            if not allowed_file(file.filename):
                return jsonify({"error": f"Unsupported file type '{ext}'. Please upload PDF, DOCX, or TXT."}), 400

            # Write file to secure temporary file
            with tempfile.NamedTemporaryFile(delete=False, suffix=ext) as tf:
                file.save(tf.name)
                temp_path = tf.name

            result = analyzer_engine.analyze(resume_path=temp_path, jd_text=jd_text if jd_text else None)
        elif resume_text:
            result = analyzer_engine.analyze(resume_text=resume_text, jd_text=jd_text if jd_text else None)
        else:
            return jsonify({"error": "Please provide a resume file or paste resume text."}), 400

        return jsonify(result)

    except Exception as e:
        return jsonify({"error": f"Analysis failed: {str(e)}"}), 500
    finally:
        if temp_path and os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except Exception:
                pass


@app.route("/report", methods=["POST"])
def render_printable_report():
    """Render a dedicated, printable ATS Audit Report."""
    try:
        report_data = request.json or {}
        return render_template("report.html", data=report_data)
    except Exception as e:
        return f"Error generating report: {str(e)}", 500


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print("=" * 60)
    print(f"[*] Resume Analyzer running locally at: http://127.0.0.1:{port}")
    print("[*] 100% Offline | Zero LLM API Keys | Privacy Preserved")
    print("=" * 60)
    app.run(host="127.0.0.1", port=port, debug=False)
