# 🚀 Resume Analyzer (100% Offline • No LLM API Keys)

A private, lightning-fast, and comprehensive **Resume Analyzer and ATS Compatibility Engine** built entirely in Python using offline Natural Language Processing (NLP), Scikit-Learn TF-IDF vectorization, regex heuristic parsing, and an extensive 1,200+ skill taxonomy.

> **Key Feature**: Zero dependence on OpenAI, Claude, Gemini, Groq, or any external API keys. Your resume data never leaves your computer, ensuring complete privacy.

---

## 🌟 Core Features

1. **Multi-Format Text Extraction**:
   - Parses text from **PDF** (`pypdf`), **Word documents** (`python-docx`), and **Plain Text / Markdown** (`.txt`, `.md`).
   - Detects scanned image PDFs and alerts if text is unextractable.

2. **Structural Information Extraction**:
   - **Contact Information**: Email, Phone Number, LinkedIn, GitHub, and Portfolio URLs.
   - **Candidate Name**: Intelligent heuristic extraction from header blocks.
   - **Section Segmentation**: Verifies the presence of Summary, Experience, Education, Skills, Projects, and Certifications.
   - **Education & Experience**: Degrees (B.Tech, B.S., M.S., Ph.D., MBA, etc.), estimated years of experience, and job title recognition.

3. **Skills Taxonomy (1,200+ Skills Across 14 Domains)**:
   - Covers Programming Languages, Frontend & Web, Backend & APIs, Databases, Cloud & DevOps, AI/ML/Data Science, Big Data, Mobile, Testing/QA, Cybersecurity, Architecture, and Soft Skills.
   - Word-boundary matching handles tokens like `C++`, `C#`, `.NET`, `Node.js`, and `CI/CD`.

4. **Objective ATS Scoring Engine (0 - 100 Points)**:
   Calculates scores across 5 standard industry pillars:
   - **Sections & Contact Info** (20 pts)
   - **Quantified Impact & Metrics** (25 pts - audits usage of numbers, %, $, scale)
   - **Action Verbs & Phrasing** (20 pts - evaluates strong leadership verbs vs passive phrases)
   - **Skills Depth & Diversity** (20 pts - counts skills and domain coverage)
   - **Length & Readability** (15 pts - checks optimal 400-950 word density)

5. **Job Description Matching (TF-IDF & Cosine Similarity)**:
   - Calculates **TF-IDF unigram/bigram cosine similarity** against any job posting.
   - Compares required skills vs candidate skills:
     * **Matched Skills** (Green badges)
     * **Missing Skills** (Red badges with recommendations)
   - Identifies high-value job keywords missing from your resume.
   - Verifies if candidate meets minimum requested experience years.

6. **Actionable Hiring & ATS Recommendations**:
   - Prioritized into **Critical Fixes**, **Recommended Polish**, and **Strengths**.
   - Encourages Google's **XYZ Formula**: *"Accomplished [X] as measured by [Y], by doing [Z]"*.

---

## 📁 Project Structure

```
ResumeAnalyzer/
├── app.py                     # Flask Web Dashboard & REST API
├── analyze_cli.py             # Terminal Command Line Interface (CLI)
├── requirements.txt           # Python package dependencies
├── README.md                  # Project documentation
├── core/
│   ├── __init__.py
│   ├── analyzer.py            # Unified analysis orchestrator
│   ├── extractor.py           # Multi-format PDF/DOCX/TXT file extractor
│   ├── cleaner.py             # Normalization and sentence segmentation
│   ├── parser.py              # Candidate info, sections, education, experience
│   ├── skills_database.py     # 1,200+ categorized skills, action verbs, weak words
│   ├── skills_matcher.py      # Boundary-accurate skill extraction & comparison
│   ├── ats_scorer.py          # 5-Pillar ATS scoring formula
│   ├── jd_matcher.py          # TF-IDF cosine similarity & keyword gap analyzer
│   └── feedback_generator.py  # Prioritized actionable resume recommendations
├── static/
│   ├── css/
│   │   └── style.css          # Responsive styling & progress meters
│   └── js/
│       └── main.js            # Drag & drop upload, sample loading, dynamic rendering
├── templates/
│   └── index.html             # Interactive Web Dashboard
└── samples/
    ├── sample_resume_swe.txt  # Sample Software Engineer resume
    ├── sample_jd_swe.txt      # Sample Software Engineer job description
    ├── sample_resume_ds.txt   # Sample Data Scientist resume
    └── sample_jd_ds.txt       # Sample Data Scientist job description
```

---

## 🚀 Getting Started

### 1. Prerequisites & Installation

Ensure you have Python 3.8+ installed. All required packages can be installed via:

```bash
python -m pip install -r requirements.txt
```

*(Core dependencies: `flask`, `pypdf`, `python-docx`, `scikit-learn`, `numpy`, `scipy`, `nltk`)*

---

### 2. Launch the Interactive Web Dashboard

Start the local web server:

```bash
python app.py
```

Then open your browser and visit:
👉 **[http://127.0.0.1:5000](http://127.0.0.1:5000)**

#### Web Features:
- **Drag & drop** your PDF or Word document resume.
- Alternatively, **paste raw resume text**.
- Paste an optional **Job Description** to compare against.
- Click **"⚡ Try an instant sample"** to test immediately with built-in Software Engineer or Data Scientist profiles.
- View **ATS Scorecard**, **Skills Breakdown**, **Profile Details**, and **Actionable Feedback**.
- Click **"Print / Save PDF"** to generate a printable report.

---

### 3. Using the Terminal Command Line Interface (CLI)

You can analyze resumes directly from your command line:

#### Run on Bundled Samples:
```bash
python analyze_cli.py --sample
```

#### Analyze a Resume File:
```bash
python analyze_cli.py --resume path/to/resume.pdf
```

#### Compare Resume with a Job Description:
```bash
python analyze_cli.py --resume path/to/resume.pdf --jd path/to/job_description.txt
```

#### Export as JSON Output:
```bash
python analyze_cli.py --resume path/to/resume.pdf --json
```

---

## 🔒 Privacy & Performance

- **Zero API Keys**: No need for OpenAI tokens, credit cards, or cloud accounts.
- **100% Offline**: Runs on your CPU locally in under 0.2 seconds per resume.
- **Completely Private**: Sensitive personal contact information and employment history never leave your machine.
